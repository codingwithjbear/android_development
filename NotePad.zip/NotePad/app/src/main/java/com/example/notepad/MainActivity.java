package com.example.notepad;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener{

    private static final String TAG = "MainActivity";
    public static ArrayList<Notes> notesList = new ArrayList<>();

    private RecyclerView recyclerView;
    public static NotesAdapter notesAdapter ;






    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTitle("Multi Notes");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);
        notesAdapter = new NotesAdapter(notesList, this);

        recyclerView.setAdapter(notesAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        loadFile();
       if(!notesList.isEmpty()){
           setTitle(String.format("Multi Notes (%d)", notesList.size()));
       }

    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.note_menu, menu); //inflating turns the xml into a live object

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.addIcon:
                openAdd();
                break;
            case R.id.infoIcon:
                openInfo();
                break;
        }
        return true;
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public boolean onLongClick(View v) {
        deleteclick(v);
        return true;
    }

    public void openInfo(){
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    public  void openAdd(){
        Intent intent = new Intent(this, Edit_Activity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }
    public void deleteclick(View v) {
        // Single input value dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        final int pos = recyclerView.getChildLayoutPosition(v);
        final int posR = notesList.size() - (pos + 1);
        Notes n = notesList.get(posR);
        String title = n.getTitle();


        builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                notesList.remove(posR);
                notesAdapter.notifyDataSetChanged();
                try {
                    saveNotes();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
                setTitle(String.format("Multi Notes (%d)", notesList.size()));
            }
        });
        builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
          //do nothing
            }
        });

        builder.setTitle("Delete Note '" + title + "'?");

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    protected void onPause() {

        try {
            saveNotes();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.onPause();
    }

    protected void onResume(){

        if(!notesList.isEmpty()){
            setTitle(String.format("Multi Notes (%d)", notesList.size()));
        }
        super.onResume();

    }
    private void saveNotes() throws IOException, JSONException {

        Log.d(TAG, "saving JSON file: Saving JSON File");

        FileOutputStream fos = getApplicationContext().
                openFileOutput(getString(R.string.fileName), Context.MODE_PRIVATE);

        JSONArray jsonArray = new JSONArray();

        for (Notes n : notesList) {
            JSONObject noteJSON = new JSONObject();
            noteJSON.put("title", n.getTitle());
            noteJSON.put("date", n.getDate());
            noteJSON.put("noteText", n.getNotes());

            jsonArray.put(noteJSON);

        }

        String jsonText = jsonArray.toString();

        fos.write(jsonText.getBytes());
        fos.close();
    }
    private void loadFile() {

        Log.d(TAG, "loadFile: Loading JSON File");
        try {
            InputStream is = getApplicationContext().
                    openFileInput(getString(R.string.fileName));

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();

            Log.d(TAG, "loadFile: JSON: " + sb.toString());

            JSONArray jsonArray = new JSONArray(sb.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                String title = jsonObject.getString("title");
                String date = jsonObject.getString("date");
                String note = jsonObject.getString("noteText");
                Notes n = new Notes(title, date, note);
                notesList.add(n);
            }




        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }





}
