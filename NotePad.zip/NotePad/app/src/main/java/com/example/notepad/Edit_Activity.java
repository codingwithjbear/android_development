package com.example.notepad;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;

public class Edit_Activity extends AppCompatActivity {

    public static EditText title;
    public static  EditText note;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_);
        setTitle("Multi Notes");

        title = findViewById(R.id.noteTitle);
        note = findViewById(R.id.noteText);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.editmenu, menu); //inflating turns the xml into a live object

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.saveIcon:
                if(!title.getText().toString().trim().equals("")) {
                    String titleText = title.getText().toString();
                    String noteText = note.getText().toString();
                    DateFormat df = new SimpleDateFormat("EEE MMM d, hh:mm a");
                    String date = df.format(Calendar.getInstance().getTime());
                    Notes prod = new Notes(titleText, date, noteText);

                    MainActivity.notesList.add(prod);
                    MainActivity.notesAdapter.notifyDataSetChanged();
                    title.setText("");
                    note.setText("");
                }
                else {
                    Context context = getApplicationContext();
                    CharSequence text = "Could not save, no title";
                    int duration = Toast.LENGTH_SHORT;
                    Toast toast = Toast.makeText(context, text, duration);
                    toast.show();
                }
                Edit_Activity.super.onBackPressed();
                break;

        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if(!title.getText().toString().trim().equals("")) {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    String titleText = title.getText().toString();
                    String noteText = note.getText().toString();
                    DateFormat df = new SimpleDateFormat("EEE MMM d, hh:mm a");
                    String date = df.format(Calendar.getInstance().getTime());
                    Notes prod = new Notes(titleText, date, noteText);

                    MainActivity.notesList.add(prod);
                    MainActivity.notesAdapter.notifyDataSetChanged();
                    title.setText("");
                    note.setText("");
                    Edit_Activity.super.onBackPressed();

                }
            });
            builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Edit_Activity.super.onBackPressed();

                }
            });
            EditText title = findViewById(R.id.noteTitle);
            String titleText = title.getText().toString();

            builder.setTitle("Your note is not saved!");
            builder.setMessage("Save Note '" + titleText + "'?");

            AlertDialog dialog = builder.create();
            dialog.show();
        }
        else{
            Context context = getApplicationContext();
            CharSequence text = "Could not save, no title";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, text, duration);
            toast.show();

            super.onBackPressed();
        }


    }

}
