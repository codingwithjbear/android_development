package com.example.notepad;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class NotesAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private static final String TAG = "NotesAdapter";
    private ArrayList<Notes> nList;
    private MainActivity mainActivity;
    NotesAdapter(ArrayList<Notes> list, MainActivity mainActivity){
        nList = list;
        this.mainActivity = mainActivity;
    }

   // private MainActivity mainAct;
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.note_row, parent, false);

        Log.d(TAG, "onCreateViewHolder: Creating view");


        itemView.setOnClickListener(mainActivity);
        itemView.setOnLongClickListener(mainActivity);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final int posR = nList.size() - (position + 1);
        Notes noteSelected = nList.get(posR);
        holder.title.setText(noteSelected.getTitle());
        holder.date.setText(noteSelected.getDate());
        if(noteSelected.getNotes().length() > 80){
            String setNote = noteSelected.getNotes().substring(0,81) + "...";
            holder.notes.setText(setNote);
        }
        else {
            holder.notes.setText(noteSelected.getNotes());
        }
    }

    @Override
    public int getItemCount() {
        return nList.size();
    }
}
