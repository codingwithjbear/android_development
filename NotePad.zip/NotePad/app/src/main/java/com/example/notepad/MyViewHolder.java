package com.example.notepad;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

    public class MyViewHolder extends RecyclerView.ViewHolder {


        TextView title;
      //  TextView latin;
        TextView date;
        TextView notes;

        MyViewHolder(View view) {
            super(view);
            title = view.findViewById(R.id.notesTitle);
            date = view.findViewById(R.id.dateField);
            notes = view.findViewById(R.id.noteField);
        }
    }
