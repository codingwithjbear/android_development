package com.example.converter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;



public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    private static final String TAG = "MainActivity";


    public boolean fToC = true;

    public void onRadioButtonClicked(View v) {
        boolean checked = ((RadioButton) v).isChecked();

        switch (v.getId()) {
            case R.id.FRadio:
                if (checked) {
                    fToC = true;
                    TextView f = findViewById(R.id.Ftext);
                    TextView c = findViewById(R.id.Ctext);

                    String fText = "Fahrenheit Degrees:";
                    String cText = "Celsius Degrees:";

                    f.setText(fText);
                    c.setText(cText);
                    break;
                }
            case R.id.CRadio:
                if (checked){
                    fToC = false;
                    TextView f = findViewById(R.id.Ftext);
                    TextView c = findViewById(R.id.Ctext);

                    String fText = "Fahrenheit Degrees:";
                    String cText = "Celsius Degrees:";

                    f.setText(cText);
                    c.setText(fText);
                    break;
                }
        }
    }

    public void Convert(View v) {

        String name = ((Button) v).getText().toString();

        Log.d(TAG, "Convert: " + name);

        EditText inPut = findViewById(R.id.input);
        TextView outPut = findViewById(R.id.output);
        TextView history = findViewById(R.id.HistoryBox);
        history.setMovementMethod(new ScrollingMovementMethod());
        Log.d(TAG, "Convert: " + inPut.getText());

        double value = 0;
        if(!(inPut.getText().toString().trim().equals(""))){
            value = Double.parseDouble(inPut.getText().toString());
        }
        if(fToC) {
            double result = (value - 32.0) / 1.8;
            String orig = history.getText().toString();
            String output = String.format("%.1f F => %.1f C %n", value, result);
            history.setText(output + orig);
            String out = String.format("%.1f %n", result);
            outPut.setText(out);
        }

        if(!fToC){
            double result = (value * 1.8) + 32.0;
            String orig = history.getText().toString();
            String output = String.format("%.1f C => %.1f F %n", value, result);
            history.setText(output + orig);
            String out = String.format("%.1f %n", result);
            outPut.setText(out);
        }

    }

    public void Clear (View v){
        TextView history = findViewById(R.id.HistoryBox);
        history.setText("");
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        TextView history = findViewById(R.id.HistoryBox);
        TextView outPut = findViewById(R.id.output);
        outState.putString("HISTORY", history.getText().toString());
        outState.putString("OutPut", outPut.getText().toString());

        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        TextView history = findViewById(R.id.HistoryBox);
        TextView outPut = findViewById(R.id.output);
        super.onRestoreInstanceState(savedInstanceState);

        history.setText(savedInstanceState.getString("HISTORY"));
        outPut.setText(savedInstanceState.getString("OutPut"));
    }



}
