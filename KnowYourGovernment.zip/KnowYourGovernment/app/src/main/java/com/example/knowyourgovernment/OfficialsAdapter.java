package com.example.knowyourgovernment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class OfficialsAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private static final String TAG = "NotesAdapter";
    private ArrayList<Officials> nList;
    private MainActivity mainActivity;
    OfficialsAdapter(ArrayList<Officials> list, MainActivity mainActivity){
        nList = list;
        this.mainActivity = mainActivity;
    }

   // private MainActivity mainAct;
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.officials_row, parent, false);

        Log.d(TAG, "onCreateViewHolder: Creating view");


        itemView.setOnClickListener(mainActivity);
        itemView.setOnLongClickListener(mainActivity);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        final int posR = position;
        Officials noteSelected = nList.get(posR);
        holder.title.setText(noteSelected.getRole());
        holder.officialsInfo.setText(noteSelected.getNameParty());

    }

    @Override
    public int getItemCount() {
        return nList.size();
    }
}
