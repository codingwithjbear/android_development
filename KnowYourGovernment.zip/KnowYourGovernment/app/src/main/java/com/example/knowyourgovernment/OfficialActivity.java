package com.example.knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.util.Linkify;
import android.util.Log;
import android.view.View;
import android.view.textclassifier.TextLinks;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class OfficialActivity extends AppCompatActivity {
    private static final String TAG = "OfficialActivity";
    private ImageView officialImage;
    private ImageView logoImage;
    private int index;
    public static String photoURL;
    public static String logoURL;
    private static String fb;
    private static String google;
    private static String twitter;
    private static String youTube;
    public static String color;
    public static String offName;
    public static String offTitle;
    public static String json;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_official);
        google = fb = twitter = youTube = null;

        officialImage = findViewById(R.id.detailPhoto);
        logoImage = findViewById(R.id.partyLogo2);
        //index = MainActivity.map.get(MainActivity.key);
        Intent intent = getIntent();
        if(intent.hasExtra("index")){
            index = intent.getIntExtra("index",0);
            Log.d(TAG, "onCreate: " + "i have index" + index);
        }
        if(intent.hasExtra("json")){
            json = intent.getStringExtra("json");
            Log.d(TAG, "onCreate: " + "i have json: " + json);
        }


       // parseJSONoffices(MainActivity.json);
        parseJSONoffices(json);
        ((TextView) findViewById(R.id.location3)).setText(MainActivity.location);
        if(google == null){
            ImageView goog = findViewById(R.id.googleLogo);
            goog.setVisibility(View.INVISIBLE);

        }
        if(fb == null){
            ImageView fb = findViewById(R.id.facebookLogo);
            fb.setVisibility(View.INVISIBLE);

        }
        if(twitter == null){
            ImageView tw = findViewById(R.id.twiterLogo);
            tw.setVisibility(View.INVISIBLE);

        }
        if(youTube == null){
            ImageView yt = findViewById(R.id.youtubeLogo);
            yt.setVisibility(View.INVISIBLE);

        }

        TextView phone = findViewById(R.id.phone);
        TextView email = findViewById(R.id.email);
        TextView website = findViewById(R.id.website);
        TextView address = findViewById(R.id.address);
        Linkify.addLinks(email, Linkify.ALL);
        email.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(phone, Linkify.ALL);
        phone.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(website, Linkify.ALL);
        website.setLinkTextColor(Color.WHITE);
        Linkify.addLinks(address, Linkify.ALL);
        address.setLinkTextColor(Color.WHITE);
        Log.d(TAG, "address : " + address.getText().toString());
    }
    private void parseJSONoffices(String s) {
        try {
            JSONObject jStocks = new JSONObject(s);
            JSONArray officials = jStocks.getJSONArray("officials");
            Log.d(TAG, "parseJSONoffices: " + jStocks);


            JSONObject jofficials = officials.getJSONObject(index);
            Log.d(TAG, "parseJSONoffices: " + "channels pre");
            if(jofficials.has("channels")) {
                Log.d(TAG, "parseJSONoffices: " + "channels post");
                JSONArray channels = jofficials.getJSONArray("channels");
                for (int i = 0; i < channels.length(); i++) {
                    String type = channels.getJSONObject(i).getString("type");
                    if (type.equals("GooglePlus")) {
                        google = channels.getJSONObject(i).getString("id");
                    }
                    if (type.equals("Facebook")) {
                        fb = channels.getJSONObject(i).getString("id");
                        Log.d(TAG, "fb " + fb);
                    }
                    if (type.equals("Twitter")) {
                        twitter = channels.getJSONObject(i).getString("id");
                        Log.d(TAG, "tweet " + twitter);
                    }
                    if (type.equals("YouTube")) {
                        youTube = channels.getJSONObject(i).getString("id");
                    }
                }

            }
            if(jofficials.has("address")) {
                JSONArray jAddress = jofficials.getJSONArray("address");
                String line1 = "";
                String line2 = "";
                String line3 = "";
                String city = "";
                String state = "";
                String zip = "";
                int i = jAddress.length() - 1;

                if(jAddress.getJSONObject(i).has("line1"))
                 line1 = jAddress.getJSONObject(i).getString("line1");
                if(jAddress.getJSONObject(i).has("line2"))
                 line2 = jAddress.getJSONObject(i).getString("line2");
                if(jAddress.getJSONObject(i).has("line3"))
                 line3 = jAddress.getJSONObject(i).getString("line3");
                if(jAddress.getJSONObject(i).has("city"))
                 city = jAddress.getJSONObject(i).getString("city");
                if(jAddress.getJSONObject(i).has("state"))
                 state = jAddress.getJSONObject(i).getString("state");
                if(jAddress.getJSONObject(i).has("zip"))
                 zip = jAddress.getJSONObject(i).getString("zip");

                Log.d(TAG, "parseJSONoffices: " + line1);
                Log.d(TAG, "parseJSONoffices: " + line2);
                Log.d(TAG, "parseJSONoffices: " + line3);
                Log.d(TAG, "parseJSONoffices: " + city);
                Log.d(TAG, "parseJSONoffices: " + state);
                Log.d(TAG, "parseJSONoffices: " + zip);
                String adres = line1.trim() +"\n" + line2.trim() + "\n" + city.trim() + ", " + state.trim() + " " + zip.trim();
                if(!line3.isEmpty()) {
                    adres = line1.trim() +"\n" + line2.trim() + "\n" + line3.trim() + "\n" + city.trim() + ", " + state.trim() + " " + zip.trim();
                }
                ((TextView) findViewById(R.id.address)).setText(adres);

            }
            if(!jofficials.has("address")){
                findViewById(R.id.address).setVisibility(View.INVISIBLE);
                findViewById(R.id.addressText).setVisibility(View.INVISIBLE);
            }



            String officialName = officials.getJSONObject(index).getString("name");
            offName = officialName;

            String party = officials.getJSONObject(index).getString("party");
            String title = MainActivity.officeTitle;
            offTitle = title;
            if(officials.getJSONObject(index).has("urls")) {
                String urls = (String) officials.getJSONObject(index).getJSONArray("urls").get(0);
                ((TextView) findViewById(R.id.website)).setText(urls);
            }
            if(!officials.getJSONObject(index).has("urls")){
                findViewById(R.id.website).setVisibility(View.INVISIBLE);
                findViewById(R.id.websiteText).setVisibility(View.INVISIBLE);
            }
            if(officials.getJSONObject(index).has("phones")) {
                String phones = (String) officials.getJSONObject(index).getJSONArray("phones").get(0);
                ((TextView) findViewById(R.id.phone)).setText(phones);
            }
            if(!officials.getJSONObject(index).has("phones")){
                findViewById(R.id.phone).setVisibility(View.INVISIBLE);
                findViewById(R.id.phoneText).setVisibility(View.INVISIBLE);
            }
            if(officials.getJSONObject(index).has("emails")) {
                String emails = (String) officials.getJSONObject(index).getJSONArray("emails").get(0);
                ((TextView) findViewById(R.id.email)).setText(emails);
            }
            if(!officials.getJSONObject(index).has("emails")){
                findViewById(R.id.email).setVisibility(View.INVISIBLE);
                findViewById(R.id.emailText).setVisibility(View.INVISIBLE);
            }
            ((TextView) findViewById(R.id.office)).setText(title);
            ((TextView) findViewById(R.id.name)).setText(officialName);
            ((TextView) findViewById(R.id.party)).setText("(" +party+ ")");

            String photoUrl = null;
            if(jofficials.has("photoUrl")){
                photoUrl = jofficials.getString("photoUrl");
                loadRemoteImage(photoUrl);
                photoURL = photoUrl;
            }
            if(!jofficials.has("photoUrl")){
                Drawable missing = getResources().getDrawable(R.drawable.missing);
                officialImage.setImageDrawable(missing);
                photoURL = null;
            }


            ConstraintLayout cl = (ConstraintLayout) findViewById(R.id.inConstraint);

            if(party.startsWith("Demo")){
                Drawable demlogo = getResources().getDrawable(R.drawable.dem_logo);
                logoImage.setImageDrawable(demlogo);
                color = "blue";
                cl.setBackgroundColor(Color.BLUE);

            }
            if(party.startsWith("Rep")){
                Drawable replogo = getResources().getDrawable(R.drawable.rep_logo);
                logoImage.setImageDrawable(replogo);
                color = "red";
                cl.setBackgroundColor(Color.RED);

            }
            if(!party.startsWith("Rep") && !party.startsWith("Demo")){
                color = "black";
                cl.setBackgroundColor(Color.BLACK);
            }




        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void openDetail(View v) {
        Intent intent = new Intent(this, PhotoDetailActivity.class);
        if(!color.isEmpty()){
            intent.putExtra("color", color);
            intent.putExtra("photoURL", photoURL);
        }
        if(photoURL != null)
        startActivity(intent);

    }

    public void onLogo(View v) {
        if(color.equals("blue")){
            String uri = "https://democrats.org";
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            startActivity(browserIntent);
        }
        else{
            String uri = "https://www.gop.com";
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            startActivity(browserIntent);
        }

    }



    private void loadRemoteImage(final String imageURL) {
        // Needs gradle  implementation 'com.squareup.picasso:picasso:2.71828'

        Log.d(TAG, "loadImage: " + imageURL);

        Picasso picasso = new Picasso.Builder(this).build();
        picasso.setLoggingEnabled(true);
        picasso.load(imageURL)
                .fit()
                    .error(R.drawable.brokenimage)
                    .placeholder(R.drawable.placeholder)
                    .into(officialImage);

    }

    public void twitterClicked(View v) {
        Intent intent = null;
        String name = twitter;
        try {
            // get the Twitter app if possible
            getPackageManager().getPackageInfo("com.twitter.android", 0);
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("twitter://user?screen_name=" + name));
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        } catch (Exception e) {
            // no Twitter app, revert to browser
            intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/" + name));
        }
        startActivity(intent);
    }

    public void facebookClicked(View v) {
        String name = fb;
        String FACEBOOK_URL = "https://www.facebook.com/" + name;
        String urlToUse;

        PackageManager packageManager = getPackageManager();
        try {
            int versionCode = packageManager.getPackageInfo("com.facebook.katana", 0).versionCode;
            if (versionCode >= 3002850) { //newer versions of fb app
                urlToUse = "fb://facewebmodal/f?href=" + FACEBOOK_URL;
            } else { //older versions of fb app
             //  urlToUse = "fb://page/" + channels.get("Facebook");
            }
        } catch (PackageManager.NameNotFoundException e) {
            urlToUse = FACEBOOK_URL; //normal web url
            // }
            Intent facebookIntent = new Intent(Intent.ACTION_VIEW);
            facebookIntent.setData(Uri.parse(urlToUse));
            startActivity(facebookIntent);
        }
    }
    public void googlePlusClicked(View v) {
        String name = google;
        Intent intent = null;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setClassName("com.google.android.apps.plus",
                    "com.google.android.apps.plus.phone.UrlGatewayActivity");
            intent.putExtra("customAppUri", name);
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://plus.google.com/" + name)));
        }
    }

    public void youTubeClicked(View v) {
        String name =
                youTube;
        Intent intent = null;
        try {
            intent = new Intent(Intent.ACTION_VIEW);
            intent.setPackage("com.google.android.youtube");
            intent.setData(Uri.parse("https://www.youtube.com/" + name));
            startActivity(intent);
        } catch (ActivityNotFoundException e) {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/" + name)));
        }
    }
}
