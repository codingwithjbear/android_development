package com.example.knowyourgovernment;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class PhotoDetailActivity extends AppCompatActivity {
    private static final String TAG = "PhotoDetailActivity";
    private ImageView officialImage;
    private ImageView logoImage;
    private TextView name;
    private TextView title;
    public static String color;
    public static String photoURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_photo_detail);

        ConstraintLayout cl = (ConstraintLayout) findViewById(R.id.detialBack);


        officialImage = findViewById(R.id.detailPhoto2);
        logoImage = findViewById(R.id.partyLogo3);
        name = findViewById(R.id.name2);
        title = findViewById(R.id.office);
        ((TextView) findViewById(R.id.location2)).setText(MainActivity.location);
        Intent intent = getIntent();
        if(intent.hasExtra("color")){
            color = intent.getStringExtra("color");
            Log.d(TAG, "onCreate: " + "I got color " + color);
        }
        if(intent.hasExtra("photoURL")){
            photoURL = intent.getStringExtra("photoURL");
            Log.d(TAG, "onCreate: " + "i got photoURL " + photoURL);
            loadRemoteImage(photoURL);
        }
/*
        if(OfficialActivity.photoURL != null){
            loadRemoteImage(OfficialActivity.photoURL);
        }
        if(OfficialActivity.photoURL == null){
            Drawable missing = getResources().getDrawable(R.drawable.missing);
            officialImage.setImageDrawable(missing);
        }


        if(OfficialActivity.color.equals("red")){
            Drawable replogo = getResources().getDrawable(R.drawable.rep_logo);
            logoImage.setImageDrawable(replogo);
            cl.setBackgroundColor(Color.RED);
        }
        if(OfficialActivity.color.equals("blue")){
            Drawable demlogo = getResources().getDrawable(R.drawable.dem_logo);
            logoImage.setImageDrawable(demlogo);
            cl.setBackgroundColor(Color.BLUE);
        }

 */
        if(color.equals("red")){
            Drawable replogo = getResources().getDrawable(R.drawable.rep_logo);
            logoImage.setImageDrawable(replogo);
            cl.setBackgroundColor(Color.RED);
        }
        if(color.equals("blue")){
            Drawable demlogo = getResources().getDrawable(R.drawable.dem_logo);
            logoImage.setImageDrawable(demlogo);
            cl.setBackgroundColor(Color.BLUE);
        }
        if(color.equals("black")){
            Drawable demlogo = getResources().getDrawable(R.drawable.dem_logo);
            logoImage.setImageDrawable(demlogo);
            cl.setBackgroundColor(Color.BLACK);
        }

        name.setText(OfficialActivity.offName);
        title.setText(OfficialActivity.offTitle);

    }
    private void loadRemoteImage(final String imageURL) {
        // Needs gradle  implementation 'com.squareup.picasso:picasso:2.71828'


        Picasso picasso = new Picasso.Builder(this).build();
        picasso.load(imageURL)
                .fit()
                .error(R.drawable.brokenimage)
                .placeholder(R.drawable.placeholder)
                .into(officialImage);

    }
}
