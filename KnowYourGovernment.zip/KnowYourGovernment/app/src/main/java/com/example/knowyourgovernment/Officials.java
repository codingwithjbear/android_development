package com.example.knowyourgovernment;

public class Officials {
    private String role;
    private String nameParty;

    public Officials(String title, String date) {
        this.role = title;
        this.nameParty = date;
    }

    public String getRole(){
        return role;
    }



    public String getNameParty() {
        return nameParty;
    }


    @Override
    public String toString() {
        return "Notes{" +
                "title='" + role + '\'' +
                ", date='" + nameParty + '\''
                ;
    }
}
