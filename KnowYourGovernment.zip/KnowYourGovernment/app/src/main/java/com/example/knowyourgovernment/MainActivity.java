package com.example.knowyourgovernment;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import static android.content.pm.PackageManager.PERMISSION_GRANTED;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener{

    private static final String TAG = "MainActivity";
    public static ArrayList<Officials> officialsList = new ArrayList<>();

    private RecyclerView recyclerView;
    private boolean noConnection;
    public static OfficialsAdapter officialsAdapter;

    private static int MY_LOCATION_REQUEST_CODE_ID = 329;
    private LocationManager locationManager;
    private Criteria criteria;
   // private String apiKey = "AIzaSyDBbtxjTXWvz-XiTxo8MP_aq5Zit_tksKk";
    public String city;
    public static String location;
    public static String json;
    public static HashMap<String, Integer> map = new HashMap<>();
    public static String key;
    public static String officeTitle;

///    public TextView location = findViewById(R.id.location);






    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("Know Your Government");
        Log.d(TAG, "onCreate: ");


        recyclerView = findViewById(R.id.recycler);
        officialsAdapter = new OfficialsAdapter(officialsList, this);

        recyclerView.setAdapter(officialsAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        officialsList.removeAll(officialsList);
        officialsAdapter.notifyDataSetChanged();
        //permissions

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        criteria = new Criteria();

        criteria.setPowerRequirement(Criteria.POWER_LOW);
        //criteria.setPowerRequirement(Criteria.POWER_HIGH);

        criteria.setAccuracy(Criteria.ACCURACY_MEDIUM);
        //criteria.setAccuracy(Criteria.ACCURACY_FINE);

        criteria.setAltitudeRequired(false);
        criteria.setBearingRequired(false);
        criteria.setSpeedRequired(false);
       // doNetCheck();

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{
                            Manifest.permission.ACCESS_FINE_LOCATION
                    },
                    MY_LOCATION_REQUEST_CODE_ID);
        } else {
            setLocation();
        }
       // doNetCheck();

            if(city != null) {
                new normalizedAsync(this).execute(city);
            }
            if(city == null){
                ((TextView) findViewById(R.id.location)).setText("No Data For Location");
            }

        doNetCheck();
        if(noConnection){
            ((TextView) findViewById(R.id.location)).setText("No Data For Location");
        }




    }
    public void acceptResults(String result) {

        if (result == null) {
            ((TextView) findViewById(R.id.location)).setText("No Data For Location");
            return;
        }
        Log.d(TAG, "acceptResults: " + result);
        parseJSONnorm(result);
        parseJSONlist(result);
        json = result;
    }
    private String parseJSONnorm(String s) {

        try {
            JSONObject jObjMain = new JSONObject(s);
            JSONObject normalized = jObjMain.getJSONObject("normalizedInput");
            Log.d(TAG, "parseJSONResults: " + normalized);
            String city = (String) normalized.get("city");
            Log.d(TAG, "parseJSONResults: " + city);
            String state = (String) normalized.get("state");
            String zip = (String) normalized.get("zip");

            String result = city + ", " + state + " " + zip;
            location = result;

            ((TextView) findViewById(R.id.location)).setText(result.trim());


        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
    private void parseJSONlist(String s) {
        try {
            Log.d(TAG, "parseJSON: " + "jObj pre");
            JSONObject jStocks = new JSONObject(s);
            JSONArray offices = jStocks.getJSONArray("offices");
            JSONArray officials = jStocks.getJSONArray("officials");

            for(int i = 0; i < offices.length(); i++) {
                Log.d(TAG, "parseJSON: " + "jObj works");
                JSONObject title = offices.getJSONObject(i);
                JSONArray index = title.getJSONArray("officialIndices");

                int[] intArray = new int[index.length()];
                for (int k = 0; k < intArray.length; ++k) {
                    intArray[k] = index.optInt(k);
                }

                String officialName = officials.getJSONObject(intArray[0]).getString("name");
                String party = officials.getJSONObject(intArray[0]).getString("party");
                map.put(officialName,intArray[0]);
                String titles = title.getString("name");
                Log.d(TAG, "parseJSONlist: " + titles);
                Log.d(TAG, "parseJSONlist: " + officialName);

                officialsList.add(new Officials(titles, officialName + " (" + party + ")"));
                officialsAdapter.notifyDataSetChanged();

                if(intArray.length > 1){
                    for (int k = 1; k < intArray.length; ++k) {
                         officialName = officials.getJSONObject(intArray[k]).getString("name");
                         party = officials.getJSONObject(intArray[k]).getString("party");
                        map.put(officialName,intArray[k]);
                        officialsList.add(new Officials(titles, officialName + " (" + party + ")"));
                        officialsAdapter.notifyDataSetChanged();
                    }
                }
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull
            String[] permissions, @NonNull
                    int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == MY_LOCATION_REQUEST_CODE_ID) {
            if (permissions[0].equals(Manifest.permission.ACCESS_FINE_LOCATION) &&
                    grantResults[0] == PERMISSION_GRANTED) {
                setLocation();
                return;
            }
        }
        ((TextView) findViewById(R.id.location)).setText("No Data For Location");

    }

@SuppressLint("MissingPermission")
private void setLocation() {
        final Context here = this;
    runOnUiThread(new Runnable() {
        @Override
        public void run() {
    double lat;
    double lon;
    Geocoder geocoder = new Geocoder(here, Locale.getDefault());


    String bestProvider = locationManager.getBestProvider(criteria, true);

    Location currentLocation = locationManager.getLastKnownLocation(bestProvider);
    if (currentLocation != null) {
       lat = currentLocation.getLatitude();
       lon = currentLocation.getLongitude();
        Log.d(TAG, "setLocation: " + lat);
        try {
            List<Address> addresses;

            addresses = geocoder.getFromLocation(lat, lon, 10);
            city = addresses.get(0).getPostalCode();
            Log.d(TAG, "setLocation: " + addresses.get(0));
            Log.d(TAG, "setLocation: " + addresses.get(0).getPostalCode());

        } catch (IOException e) {
            e.printStackTrace();
        }

    } else {
        ((TextView) findViewById(R.id.location)).setText("No Data For Location");
    }
        }
    });


}



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu); //inflating turns the xml into a live object

        return true;
    }
    private void doAsyncLoad(String data) {

        new normalizedAsync(this).execute(data);
    }


        @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.locationIcon:
                AlertDialog.Builder builder = new AlertDialog.Builder(this);

                // Create an edittext and set it to be the builder's view
                final EditText et = new EditText(this);
                et.setInputType(InputType.TYPE_CLASS_TEXT);
                et.setGravity(Gravity.CENTER_HORIZONTAL);
                builder.setView(et);
               // final TextView location = findViewById(R.id.location);

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                      //  location.setText(et.getText());
                        officialsList.removeAll(officialsList);
                        officialsAdapter.notifyDataSetChanged();

                        doAsyncLoad(et.getText().toString());

                    }
                });
                builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                       // Toast.makeText(MainActivity.this, "You changed your mind!", Toast.LENGTH_SHORT).show();
                    }
                });

                builder.setTitle("Enter a City, State or Zip Code:");

                AlertDialog dialog = builder.create();
                dialog.show();
                break;
            case R.id.aboutIcon:
                openInfo();
                break;
        }
        return true;
    }


    @Override
    public void onClick(View v) {
        final int pos = recyclerView.getChildLayoutPosition(v);
        Officials n = officialsList.get(pos);
        String title = n.getNameParty();
        officeTitle = n.getRole();
        int i = title.indexOf("(");
        String name = title.substring(0,i-1);
        key = name;
        Log.d(TAG, "onClick: " + key);
     //   openOfficial();
        Intent intent = new Intent(MainActivity.this, OfficialActivity.class);
        if (!key.isEmpty()) {
            intent.putExtra("index", map.get(key));
            intent.putExtra("json", json);
        }
        startActivity(intent);
    }

    public void openInfo(){
        Intent intent = new Intent(this, AboutActivity.class);
        startActivity(intent);
    }

    public  void openOfficial(){
        Intent intent = new Intent(this, OfficialActivity.class);
        startActivity(intent);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    protected void onPause() {
        super.onPause();
    }

    protected void onResume(){
        super.onResume();

    }


    @Override
    public boolean onLongClick(View v) {
        return false;
    }
    private void doNetCheck() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            noConnection = false;
            return;

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Data cannot be acceased/loaded without an internet connection.");
            builder.setTitle("No Network Connection");

            AlertDialog dialog3 = builder.create();
            dialog3.show();
        }
        noConnection = true;
    }
}
