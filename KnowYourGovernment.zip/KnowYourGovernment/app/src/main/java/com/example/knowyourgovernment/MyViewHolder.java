package com.example.knowyourgovernment;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {


    TextView title;
    TextView officialsInfo;

    MyViewHolder(View view) {
        super(view);
        title = view.findViewById(R.id.officialTitle);
        officialsInfo = view.findViewById(R.id.officialsInfo);
    }
}
