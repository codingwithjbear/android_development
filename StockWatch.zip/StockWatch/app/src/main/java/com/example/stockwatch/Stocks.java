package com.example.stockwatch;

import java.io.Serializable;

public class Stocks implements Serializable {
    private String symbol;
    private String name;
    private String tradePrice;
    private String priceChange;

    public Stocks(String symbol, String name, String tradePrice, String priceChange) {
        this.symbol = symbol;
        this.name = name;
        this.tradePrice = tradePrice;
        this.priceChange = priceChange;
    }

    public String getSymbol() {
        return symbol;
    }

    public String getName() {
        return name;
    }

    public String  getTradePrice() {
        return tradePrice;
    }

    public String getPriceChange() {
        return priceChange;
    }


}
