package com.example.stockwatch;

import android.annotation.SuppressLint;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.ArrayList;


public class StockDataTask extends AsyncTask<String, Void, String> {//returns string...

    @SuppressLint("StaticFieldLeak")
    private MainActivity mainActivity;


    private static final String TAG = "StockData";

    StockDataTask(MainActivity ma) {
        mainActivity = ma;
    }


    @Override
    protected void onPostExecute(String s) {
        if(s != null) {
            Log.d(TAG, "oP: " + s);
            ArrayList<Stocks> stockList = parseJSON(s);
            if(stockList.isEmpty()) mainActivity.notFound();
            mainActivity.updateData(stockList);
        }
        else
        mainActivity.notFound();
    }


    @Override
    protected String doInBackground(String... params) {

        Uri dUri = Uri.parse(params[0]);
        String urlUse = dUri.toString();
        StringBuilder sb = new StringBuilder();
        try {
            URL url = new URL(urlUse);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            if (conn.getResponseCode() != HttpURLConnection.HTTP_OK) {
                return null;
            }

            Log.d(TAG, "doInBackground: ResponseCode: " + params[0]);

            conn.setRequestMethod("GET");

            InputStream is = conn.getInputStream();
            BufferedReader reader = new BufferedReader((new InputStreamReader(is)));

            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line).append('\n');
            }

            Log.d(TAG, "doInBackground: " + sb.toString());

        } catch (Exception e) {
            Log.e(TAG, "doInBackground: ", e);
            return null;
        }

        return sb.toString();

    }


    private ArrayList<Stocks> parseJSON(String s) {
        ArrayList<Stocks> stocksList = new ArrayList<>();
        try {
            Log.d(TAG, "parseJSON: " + "jObj pre");
            JSONObject jStocks = new JSONObject(s);
            Log.d(TAG, "parseJSON: " + "jObj works");
            String name = jStocks.getString("companyName");
            String symbol = jStocks.getString("symbol");
            double latestPrice = jStocks.getDouble("latestPrice");
            double change = jStocks.getDouble("change");
            double changePercent = jStocks.getDouble("changePercent");
            NumberFormat formatter = new DecimalFormat("#0.00");
            Log.d(TAG, "parseJSON: " + change);
            if (changePercent >= 0)
                stocksList.add(new Stocks(symbol, name, formatter.format(latestPrice), "▲" + formatter.format(change) + "(" + formatter.format(changePercent * 100) + "%)"));
            else {
                stocksList.add(new Stocks(symbol, name, formatter.format(latestPrice), "▼" + formatter.format(change) + "(" + formatter.format(changePercent * 100) + "%)"));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        return stocksList;
    }
}