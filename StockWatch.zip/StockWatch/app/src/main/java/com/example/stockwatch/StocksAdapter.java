package com.example.stockwatch;

import android.graphics.Color;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;


public class StocksAdapter extends RecyclerView.Adapter<MyViewHolder> {
    private static final String TAG = "NotesAdapter";
    private ArrayList<Stocks> nList;
    private MainActivity mainActivity;

    StocksAdapter(ArrayList<Stocks> list, MainActivity mainActivity){
        this.nList = list;
        this.mainActivity = mainActivity;
    }


    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.stock_row, parent, false);

        Log.d(TAG, "onCreateViewHolder: Creating view");


        itemView.setOnClickListener(mainActivity);
        itemView.setOnLongClickListener(mainActivity);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

      //  final int posR = nList.size() - (position + 1);
        Stocks noteSelected = nList.get(position);
        if(noteSelected.getPriceChange().contains("▲")) {

            holder.name.setText(noteSelected.getName());
            holder.name.setTextColor(Color.GREEN);
            holder.symbol.setText(noteSelected.getSymbol());
            holder.symbol.setTextColor(Color.GREEN);
            holder.lastTradePrice.setText("" + noteSelected.getTradePrice());
            holder.lastTradePrice.setTextColor(Color.GREEN);
            holder.priceChange.setText(noteSelected.getPriceChange());
            holder.priceChange.setTextColor(Color.GREEN);
            if(mainActivity.noConnection == true){
                holder.lastTradePrice.setText("0");
                holder.priceChange.setText("0.00(0%)");
            }
        }
        else{
            holder.name.setText(noteSelected.getName());
            holder.name.setTextColor(Color.RED);
            holder.symbol.setText(noteSelected.getSymbol());
            holder.symbol.setTextColor(Color.RED);
            holder.lastTradePrice.setText("" + noteSelected.getTradePrice());
            holder.lastTradePrice.setTextColor(Color.RED);
            holder.priceChange.setText(noteSelected.getPriceChange());
            holder.priceChange.setTextColor(Color.RED);
            if(mainActivity.noConnection == true){
                holder.lastTradePrice.setText("0");
                holder.priceChange.setText("0.00(0%)");
            }
        }

    }

    @Override
    public int getItemCount() {
        return nList.size();
    }
}
