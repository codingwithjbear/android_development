package com.example.stockwatch;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

//import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, View.OnLongClickListener{

    private static final String TAG = "MainActivity";
    public final ArrayList<Stocks> stockList = new ArrayList<>();

    private RecyclerView recyclerView;
    public static StocksAdapter stocksAdapter ;
    private String token = "sk_bb39f17acf1b4ebaaf288602a8a13c95";
    private HashMap<String, String> map = new HashMap<>();

    private SwipeRefreshLayout swiper;
    private boolean gotNames = false;
    public boolean noConnection = false;
    private String textS = "";


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        setTitle("Stock Watch");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler);
        stocksAdapter = new StocksAdapter(stockList, this);

        recyclerView.setAdapter(stocksAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        swiper = findViewById(R.id.swiper);
        swiper.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                doRefresh();
            }
        });


        loadFile();
        doNetCheck3();
        if (!noConnection) {
            new StockLoaderTask(this).execute();
            gotNames = true;
        }




    }
    public void doRefresh() {
        doNetCheck2();
        if (!noConnection) {
            if (!stockList.isEmpty()) {
                for (Iterator<Stocks> iterator = stockList.iterator(); iterator.hasNext(); ) {
                    String symbol = iterator.next().getSymbol();
                    iterator.remove();
                    String dataURL = "https://cloud.iexapis.com/stable/stock/" + symbol + "/quote?token=sk_bb39f17acf1b4ebaaf288602a8a13c95";
                    doAsyncLoad(dataURL);
                }

            }
        }
        swiper.setRefreshing(false);
    }
    public void updateData(ArrayList<Stocks> cList) {
        if(!cList.isEmpty())
        stockList.add(cList.get(0));
        try {
            saveStocks();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        stocksAdapter.notifyDataSetChanged();

    }

    public void saveData(HashMap<String, String> s) {
        map = s;
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.stock_menu, menu); //inflating turns the xml into a live object

        return true;
    }
    private void doAsyncLoad(String dataURL) {

        new StockDataTask(this).execute(dataURL);

    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item){

        switch (item.getItemId()){
            case R.id.addIcon:
                doNetCheck();
                if(!noConnection) {
                    if(!gotNames) new StockLoaderTask(this).execute();
                    final Context here = this;
                    AlertDialog.Builder builder = new AlertDialog.Builder(this);
                    final EditText et = new EditText(this);
                    et.setInputType(InputType.TYPE_CLASS_TEXT);
                    et.setGravity(Gravity.CENTER_HORIZONTAL);
                    et.setFilters(new InputFilter[]{new InputFilter.AllCaps()});
                    builder.setView(et);
                    builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {
                            Context context = getApplicationContext();
                            CharSequence text = et.getText();
                            textS = text.toString();
                            boolean same = false;
                            if (!stockList.isEmpty()) {
                                int k = stockList.size();
                                for (int i = 0; i < k; i++) {
                                    String symbol = stockList.get(i).getSymbol();
                                    if (symbol.equals(text.toString())) same = true;
                                }
                            }
                            if (same) {
                                AlertDialog.Builder builder = new AlertDialog.Builder(here);
                                builder.setIcon(R.drawable.baseline_warning_black_18dp);
                                builder.setMessage("Stock Symbol " + text + " is already displayed");
                                builder.setTitle("Duplicate Stock");

                                AlertDialog dialog3 = builder.create();
                                dialog3.show();

                            } else {
                                int count = 0;
                                Set setOfkeys = map.keySet();
                                Iterator iterator = setOfkeys.iterator();
                                while (iterator.hasNext()) {
                                    String key = (String) iterator.next();
                                    String value = (String) map.get(key);
                                    if(key.startsWith(text.toString()) || value.toUpperCase().startsWith(text.toString())){
                                        count++;
                                        Log.d(TAG, "key count++: " + text);
                                    }

                                }


                                if (count == 1) {
                                    Set setOfkeys2 = map.keySet();
                                    Iterator iterator2 = setOfkeys2.iterator();
                                    while (iterator2.hasNext()) {
                                        String key = (String) iterator2.next();
                                        String value = (String) map.get(key);
                                        if(value.toUpperCase().startsWith(text.toString())){
                                            text = key.trim();
                                            if (!stockList.isEmpty()) {
                                                int k = stockList.size();
                                                for (int i = 0; i < k; i++) {
                                                    String symbol = stockList.get(i).getSymbol();
                                                    if (symbol.equals(text.toString())) same = true;
                                                }
                                            }
                                            break;
                                        }


                                    }
                                    if (same) {
                                        AlertDialog.Builder builder = new AlertDialog.Builder(here);
                                        builder.setIcon(R.drawable.baseline_warning_black_18dp);
                                        builder.setMessage("Stock Symbol " + text + " is already displayed");
                                        builder.setTitle("Duplicate Stock");

                                        AlertDialog dialog3 = builder.create();
                                        dialog3.show();

                                    }else {

                                        String dataURL = "https://cloud.iexapis.com/stable/stock/" + text.toString().trim() + "/quote?token=sk_bb39f17acf1b4ebaaf288602a8a13c95";
                                        doAsyncLoad(dataURL);
                                    }
                                }
                                if (count > 1) {
                                    int n = map.size();
                                    final CharSequence[] sArray = new CharSequence[count];
                                    int i = 0;
                                        Set setOfkeys2 = map.keySet();
                                        Iterator iterator2 = setOfkeys2.iterator();
                                        while (iterator2.hasNext()) {
                                            String key = (String) iterator2.next();
                                            String value = (String) map.get(key);
                                            if (key.startsWith(text.toString()) || value.toUpperCase().startsWith(text.toString())) {
                                                sArray[i] = key + " - " + value;
                                                i++;
                                                Log.d(TAG, "match" + key);
                                            }
                                        }



                                    AlertDialog.Builder builder = new AlertDialog.Builder(here);
                                    builder.setTitle("Make a selection");

                                    builder.setItems(sArray, new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int which) {

                                          int dash =  sArray[which].toString().indexOf("-");
                                          boolean same2 = false;
                                          String text = sArray[which].toString().substring(0,dash);
                                            if (!stockList.isEmpty()) {
                                                int k = stockList.size();
                                                for (int i = 0; i < k; i++) {
                                                    String symbol = stockList.get(i).getSymbol();
                                                    if (symbol.equals(text.trim())) same2 = true;
                                                }
                                            }
                                            if (same2) {
                                                AlertDialog.Builder builder = new AlertDialog.Builder(here);
                                                builder.setIcon(R.drawable.baseline_warning_black_18dp);
                                                builder.setMessage("Stock Symbol " + text + " is already displayed");
                                                builder.setTitle("Duplicate Stock");

                                                AlertDialog dialog3 = builder.create();
                                                dialog3.show();

                                            }
                                            else {
                                                textS = text.trim();
                                                String dataURL = "https://cloud.iexapis.com/stable/stock/" + text.trim() + "/quote?token=sk_bb39f17acf1b4ebaaf288602a8a13c95";
                                                doAsyncLoad(dataURL);
                                                Log.d(TAG, "match  async");
                                            }
                                        }
                                    });

                                    builder.setNegativeButton("Nevermind", new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                        }
                                    });
                                    AlertDialog dialog2 = builder.create();

                                    dialog2.show();
                                }
                                if (count == 0 || text.toString().trim() == "") {
                                    AlertDialog.Builder builder = new AlertDialog.Builder(here);


                                    builder.setMessage("Data for stock symbol");
                                    builder.setTitle("Symbol Not Found: " + text);

                                    AlertDialog dialog3 = builder.create();
                                    dialog3.show();
                                }
                            }
                        }
                    });
                    builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int id) {

                        }
                    });

                    builder.setTitle("Stock Selection");
                    builder.setMessage("Please enter a Stock Symbol");

                    AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;

        }
        return true;
    }


    @Override
    public void onClick(View v) {
        final int pos = recyclerView.getChildLayoutPosition(v);
        Stocks n = stockList.get(pos);
        String symbol = n.getSymbol();

        String uri = "http://www.marketwatch.com/investing/stock/" + symbol;
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        startActivity(browserIntent);
    }


    @Override
    public boolean onLongClick(View v) {
        deleteclick(v);
        return true;
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();

    }

    public void deleteclick(View v) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setIcon(R.drawable.baseline_delete_forever_black_18dp);

        final int pos = recyclerView.getChildLayoutPosition(v);
        Stocks n = stockList.get(pos);
        String title = n.getSymbol();


        builder.setPositiveButton("DELETE", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                stockList.remove(pos);
                stocksAdapter.notifyDataSetChanged();
                try {
                    saveStocks();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        });
        builder.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
            public void onClick(DialogInterface dialog, int id) {
                //do nothing
            }
        });

        builder.setTitle("Delete Stock");
        builder.setMessage("Delete Stock Symbol " + title + "?");

        AlertDialog dialog = builder.create();
        dialog.show();
    }
    protected void onPause() {

        try {
            saveStocks();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        super.onPause();
    }


    private void saveStocks() throws IOException, JSONException {

        Log.d(TAG, "saving JSON file: Saving JSON File");

        FileOutputStream fos = getApplicationContext().
                openFileOutput(getString(R.string.fileName), Context.MODE_PRIVATE);

        JSONArray jsonArray = new JSONArray();

        for (Stocks n : stockList) {
            JSONObject stocksJSON = new JSONObject();
            stocksJSON.put("name", n.getName());
            stocksJSON.put("symbol",n.getSymbol());
            stocksJSON.put("lastTradePrice",n.getTradePrice());
            stocksJSON.put("priceChange",n.getPriceChange());

            jsonArray.put(stocksJSON);

        }

        String jsonText = jsonArray.toString();

        fos.write(jsonText.getBytes());
        fos.close();


    }
    private void loadFile() {


        Log.d(TAG, "loadFile: Loading JSON File");
        try {
            InputStream is = getApplicationContext().
                    openFileInput(getString(R.string.fileName));

            BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));

            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                sb.append(line);
            }
            reader.close();

            Log.d(TAG, "loadFile: JSON: " + sb.toString());

            JSONArray jsonArray = new JSONArray(sb.toString());
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = (JSONObject) jsonArray.get(i);
                String name = jsonObject.getString("name");
                Log.d(TAG, "got Title: " + name);
                String symbol = jsonObject.getString("symbol");
                String lastTradePrice = jsonObject.getString("lastTradePrice");
                String priceChange = jsonObject.getString("priceChange");

                Stocks n = new Stocks(symbol,name,lastTradePrice, priceChange);
                stockList.add(n);
            }




        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (Exception e) {
            e.printStackTrace();
        }


    }
    private void doNetCheck() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            noConnection = false;
            return;

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);

            builder.setMessage("Stocks Cannot Be Added Without A network Connection");
            builder.setTitle("No Network Connection");

            AlertDialog dialog3 = builder.create();
            dialog3.show();
        }
        noConnection = true;
    }
    private void doNetCheck2() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            noConnection = false;
            return;

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Stocks Cannot Be Updated Without A network Connection");
            builder.setTitle("No Network Connection");

            AlertDialog dialog3 = builder.create();
            dialog3.show();
        }
        noConnection = true;
    }

    private void doNetCheck3() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) {
            Toast.makeText(this, "Cannot access ConnectivityManager", Toast.LENGTH_SHORT).show();
            return;
        }

        NetworkInfo netInfo = cm.getActiveNetworkInfo();

        if (netInfo != null && netInfo.isConnected()) {
            noConnection = false;
            return;

        } else {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Stocks Cannot Be Updated Without A network Connection. Restart application when a connection is established");
            builder.setTitle("No Network Connection");

            AlertDialog dialog3 = builder.create();
            dialog3.show();
        }
        noConnection = true;
    }

    public void notFound(){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);


        builder.setMessage("Data for stock symbol");
        builder.setTitle("Symbol Not Found: " + textS);

        AlertDialog dialog3 = builder.create();
        dialog3.show();
    }










}
