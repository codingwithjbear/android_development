package com.example.stockwatch;

import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {


    TextView symbol;
    TextView name;
    TextView priceChange;
    TextView lastTradePrice;

    MyViewHolder(View view) {
        super(view);
        symbol = view.findViewById(R.id.symbol);
        name = view.findViewById(R.id.companyName);
        priceChange = view.findViewById(R.id.priceChange);
        lastTradePrice = view.findViewById(R.id.tradePrice);
    }
}
